# pacific-boilanger

This is the website being built for one of my college classes. We're iterating/updating the same set of files on a weekly basis, so I figured I'd start working with Git at the same time to get some more experience with it.
